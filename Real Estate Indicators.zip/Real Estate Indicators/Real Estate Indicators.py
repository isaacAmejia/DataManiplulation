# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 20:25:38 2025

@author: Isaac
"""

#This project cleans and merges data that will later be used for indicators relating to 
#real estate markets throught texas

#The data comes from the following sources:
    # - Census Bureau: American Community Survey -> Average Median Income (from Household, Families, Non-Married Families, and Non family households )
    # - Bereau of Labor Statistics -> Unnemployment percentages
    # - Crime in Texas: Incident based reporting -> Violent Crime Rates
#All three data sources will be merged by county and year for later analysis

import numpy as np
import pandas as pd

file_path = 'C:\\Users\\Isaac\\Desktop\\Real Estate Indicators' #<--- Change this to the file path for the portfolio folder

#Loading in csv files for years 2010-2023
Census = {}
for year in range (2010,2024):
    files = file_path + f'\\Census-Income\\ACSST5Y{year}.S1901.csv'
    Census[year] = pd.read_csv(files)

#assign each year a dataframe and select important columns

C2010 = Census[2010][['Label (Grouping)', 'Median income (dollars)']]
C2011 = Census[2011][['Label (Grouping)', 'Median income (dollars)']]
C2012 = Census[2012][['Label (Grouping)', 'Median income (dollars)']]
C2013 = Census[2013][['Label (Grouping)', 'Median income (dollars)']]
C2014 = Census[2014][['Label (Grouping)', 'Median income (dollars)']]
C2015 = Census[2015][['Label (Grouping)', 'Median income (dollars)']]
C2016 = Census[2016][['Label (Grouping)', 'Median income (dollars)']]
C2017 = Census[2017][['Label (Grouping)', 'Median income (dollars)']]
C2018 = Census[2018][['Label (Grouping)', 'Median income (dollars)']]
C2019 = Census[2019][['Label (Grouping)', 'Median income (dollars)']]
C2020 = Census[2020][['Label (Grouping)', 'Median income (dollars)']]
C2021 = Census[2021][['Label (Grouping)', 'Median income (dollars)']]
C2022 = Census[2022][['Label (Grouping)', 'Median income (dollars)']]
C2023 = Census[2023][['Label (Grouping)', 'Median income (dollars)']]

#------------------------------------------------------------------------------------------

#select rows that contain estimates for each category

C2010 = C2010[C2010['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2011 = C2011[C2011['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2012 = C2012[C2012['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2013 = C2013[C2013['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2014 = C2014[C2014['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2015 = C2015[C2015['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2016 = C2016[C2016['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2017 = C2017[C2017['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2018 = C2018[C2018['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2019 = C2019[C2019['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2020 = C2020[C2020['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2021 = C2021[C2021['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2022 = C2022[C2022['Label (Grouping)'].str.contains('Estimate|County', na=False)]
C2023 = C2023[C2023['Label (Grouping)'].str.contains('Estimate|County', na=False)]

#-------------------------------------------------------------------------------------------

#Strip unnecessary spaces from the 'Label (Grouping) column
#Replace all rows containing 'Estimate' with nan in the 'Label (Grouping)' column
#Forward fill the na rows with the above row containing a value (giving us all counties associated with estimates)

C2010['Label (Grouping)'] = C2010['Label (Grouping)'].str.strip()
C2010['Label (Grouping)'] = C2010['Label (Grouping)'].replace('Estimate', np.nan)
C2010['Label (Grouping)'] = C2010['Label (Grouping)'].fillna(method='ffill')

C2011['Label (Grouping)'] = C2011['Label (Grouping)'].str.strip()
C2011['Label (Grouping)'] = C2011['Label (Grouping)'].replace('Estimate', np.nan)
C2011['Label (Grouping)'] = C2011['Label (Grouping)'].fillna(method='ffill')

C2012['Label (Grouping)'] = C2012['Label (Grouping)'].str.strip()
C2012['Label (Grouping)'] = C2012['Label (Grouping)'].replace('Estimate', np.nan)
C2012['Label (Grouping)'] = C2012['Label (Grouping)'].fillna(method='ffill')

C2013['Label (Grouping)'] = C2013['Label (Grouping)'].str.strip()
C2013['Label (Grouping)'] = C2013['Label (Grouping)'].replace('Estimate', np.nan)
C2013['Label (Grouping)'] = C2013['Label (Grouping)'].fillna(method='ffill')

C2014['Label (Grouping)'] = C2014['Label (Grouping)'].str.strip()
C2014['Label (Grouping)'] = C2014['Label (Grouping)'].replace('Estimate', np.nan)
C2014['Label (Grouping)'] = C2014['Label (Grouping)'].fillna(method='ffill')

C2015['Label (Grouping)'] = C2015['Label (Grouping)'].str.strip()
C2015['Label (Grouping)'] = C2015['Label (Grouping)'].replace('Estimate', np.nan)
C2015['Label (Grouping)'] = C2015['Label (Grouping)'].fillna(method='ffill')

C2016['Label (Grouping)'] = C2016['Label (Grouping)'].str.strip()
C2016['Label (Grouping)'] = C2016['Label (Grouping)'].replace('Estimate', np.nan)
C2016['Label (Grouping)'] = C2016['Label (Grouping)'].fillna(method='ffill')

C2017['Label (Grouping)'] = C2017['Label (Grouping)'].str.strip()
C2017['Label (Grouping)'] = C2017['Label (Grouping)'].replace('Estimate', np.nan)
C2017['Label (Grouping)'] = C2017['Label (Grouping)'].fillna(method='ffill')

C2018['Label (Grouping)'] = C2018['Label (Grouping)'].str.strip()
C2018['Label (Grouping)'] = C2018['Label (Grouping)'].replace('Estimate', np.nan)
C2018['Label (Grouping)'] = C2018['Label (Grouping)'].fillna(method='ffill')

C2019['Label (Grouping)'] = C2019['Label (Grouping)'].str.strip()
C2019['Label (Grouping)'] = C2019['Label (Grouping)'].replace('Estimate', np.nan)
C2019['Label (Grouping)'] = C2019['Label (Grouping)'].fillna(method='ffill')

C2020['Label (Grouping)'] = C2020['Label (Grouping)'].str.strip()
C2020['Label (Grouping)'] = C2020['Label (Grouping)'].replace('Estimate', np.nan)
C2020['Label (Grouping)'] = C2020['Label (Grouping)'].fillna(method='ffill')

C2021['Label (Grouping)'] = C2021['Label (Grouping)'].str.strip()
C2021['Label (Grouping)'] = C2021['Label (Grouping)'].replace('Estimate', np.nan)
C2021['Label (Grouping)'] = C2021['Label (Grouping)'].fillna(method='ffill')

C2022['Label (Grouping)'] = C2022['Label (Grouping)'].str.strip()
C2022['Label (Grouping)'] = C2022['Label (Grouping)'].replace('Estimate', np.nan)
C2022['Label (Grouping)'] = C2022['Label (Grouping)'].fillna(method='ffill')

C2023['Label (Grouping)'] = C2023['Label (Grouping)'].str.strip()
C2023['Label (Grouping)'] = C2023['Label (Grouping)'].replace('Estimate', np.nan)
C2023['Label (Grouping)'] = C2023['Label (Grouping)'].fillna(method='ffill')

#-------------------------------------------------------------------------------------------------------

#Some empty row values use '-' as a placeholder, so we replace with nan
#Replace the ',' in the integers for median income with '' so we can convert them to float values
#Group the 'Label (Grouping)' column together to combine all counties and find the average of the median incomes
#reset the index to revert to the wanted columns

C2010['Median income (dollars)'] = C2010['Median income (dollars)'].replace('-', np.nan)
C2010['Median income (dollars)'] = C2010['Median income (dollars)'].str.replace(',', '').astype(float)
C2010 = C2010.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2010 = C2010.reset_index()

C2011['Median income (dollars)'] = C2011['Median income (dollars)'].replace('-', np.nan)
C2011['Median income (dollars)'] = C2011['Median income (dollars)'].str.replace(',', '').astype(float)
C2011 = C2011.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2011 = C2011.reset_index()

C2012['Median income (dollars)'] = C2012['Median income (dollars)'].replace('-', np.nan)
C2012['Median income (dollars)'] = C2012['Median income (dollars)'].str.replace(',', '').astype(float)
C2012 = C2012.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2012 = C2012.reset_index()

C2013['Median income (dollars)'] = C2013['Median income (dollars)'].replace('-', np.nan)
C2013['Median income (dollars)'] = C2013['Median income (dollars)'].str.replace(',', '').astype(float)
C2013 = C2013.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2013 = C2013.reset_index()

C2014['Median income (dollars)'] = C2014['Median income (dollars)'].replace('-', np.nan)
C2014['Median income (dollars)'] = C2014['Median income (dollars)'].str.replace(',', '').astype(float)
C2014 = C2014.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2014 = C2014.reset_index()

C2015['Median income (dollars)'] = C2015['Median income (dollars)'].replace('-', np.nan)
C2015['Median income (dollars)'] = C2015['Median income (dollars)'].replace('(X)', np.nan) #<- 2015 uses 'X' as a placeholder
C2015['Median income (dollars)'] = C2015['Median income (dollars)'].str.replace(',', '').astype(float)
C2015 = C2015.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2015 = C2015.reset_index()

C2016['Median income (dollars)'] = C2016['Median income (dollars)'].replace('-', np.nan)
C2016['Median income (dollars)'] = C2016['Median income (dollars)'].str.replace(',', '').astype(float)
C2016 = C2016.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2016 = C2016.reset_index()

C2017['Median income (dollars)'] = C2017['Median income (dollars)'].replace('-', np.nan)
C2017['Median income (dollars)'] = C2017['Median income (dollars)'].str.replace(',', '').astype(float)
C2017 = C2017.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2017 = C2017.reset_index()

C2018['Median income (dollars)'] = C2018['Median income (dollars)'].replace('-', np.nan)
C2018['Median income (dollars)'] = C2018['Median income (dollars)'].str.replace(',', '').astype(float)
C2018 = C2018.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2018 = C2018.reset_index()

C2019['Median income (dollars)'] = C2019['Median income (dollars)'].replace('-', np.nan)
C2019['Median income (dollars)'] = C2019['Median income (dollars)'].str.replace(',', '').astype(float)
C2019 = C2019.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2019 = C2019.reset_index()

C2020['Median income (dollars)'] = C2020['Median income (dollars)'].replace('-', np.nan)
C2020['Median income (dollars)'] = C2020['Median income (dollars)'].str.replace(',', '').astype(float)
C2020 = C2020.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2020 = C2020.reset_index()

C2021['Median income (dollars)'] = C2021['Median income (dollars)'].replace('-', np.nan)
C2021['Median income (dollars)'] = C2021['Median income (dollars)'].str.replace(',', '').astype(float)
C2021 = C2021.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2021 = C2021.reset_index()

C2022['Median income (dollars)'] = C2022['Median income (dollars)'].replace('-', np.nan)
C2022['Median income (dollars)'] = C2022['Median income (dollars)'].str.replace(',', '').astype(float)
C2022 = C2022.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2022 = C2022.reset_index()

C2023['Median income (dollars)'] = C2023['Median income (dollars)'].replace('-', np.nan)
C2023['Median income (dollars)'] = C2023['Median income (dollars)'].str.replace(',', '').astype(float)
C2023 = C2023.groupby('Label (Grouping)')['Median income (dollars)'].mean()
C2023 = C2023.reset_index()

#-----------------------------------------------------------------------------------------
#Split the 'Label (Grouping)' column into County and State
#Drop the old column
#Add a new column to identify the year for each dataset
C2010[['County', 'State']] = C2010['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2010.drop(columns = ['Label (Grouping)'], inplace = True)
C2010['Year'] = 2010

C2011[['County', 'State']] = C2011['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2011.drop(columns = ['Label (Grouping)'], inplace = True)
C2011['Year'] = 2011

C2012[['County', 'State']] = C2012['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2012.drop(columns = ['Label (Grouping)'], inplace = True)
C2012['Year'] = 2012

C2013[['County', 'State']] = C2013['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2013.drop(columns = ['Label (Grouping)'], inplace = True)
C2013['Year'] = 2013

C2014[['County', 'State']] = C2014['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2014.drop(columns = ['Label (Grouping)'], inplace = True)
C2014['Year'] = 2014

C2015[['County', 'State']] = C2015['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2015.drop(columns = ['Label (Grouping)'], inplace = True)
C2015['Year'] = 2015

C2016[['County', 'State']] = C2016['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2016.drop(columns = ['Label (Grouping)'], inplace = True)
C2016['Year'] = 2016

C2017[['County', 'State']] = C2017['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2017.drop(columns = ['Label (Grouping)'], inplace = True)
C2017['Year'] = 2017

C2018[['County', 'State']] = C2018['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2018.drop(columns = ['Label (Grouping)'], inplace = True)
C2018['Year'] = 2018

C2019[['County', 'State']] = C2019['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2019.drop(columns = ['Label (Grouping)'], inplace = True)
C2019['Year'] = 2019

C2020[['County', 'State']] = C2020['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2020.drop(columns = ['Label (Grouping)'], inplace = True)
C2020['Year'] = 2020

C2021[['County', 'State']] = C2021['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2021.drop(columns = ['Label (Grouping)'], inplace = True)
C2021['Year'] = 2021

C2022[['County', 'State']] = C2022['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2022.drop(columns = ['Label (Grouping)'], inplace = True)
C2022['Year'] = 2022

C2023[['County', 'State']] = C2023['Label (Grouping)'].str.split(', ', n=1, expand = True)
C2023.drop(columns = ['Label (Grouping)'], inplace = True)
C2023['Year'] = 2023

#Concatinate all of the dataframes into one
Census = [C2010, C2011, C2012, C2013, C2014, C2015, C2016, C2017, C2018, C2019, C2020, C2021, C2022, C2023]
Census = pd.concat(Census, ignore_index=True)

###############################################################################################################
###############################################################################################################

#load in the data for the BLS for years 10-23 (2010-2023)
BLS = {}
for year in range (10,24):
    files = file_path + f'\\BLS\\laucnty{year}.xlsx'
    BLS[year] = pd.read_excel(files)
    
#Assign each year to a dataframe

BLS10 = BLS[10]
BLS11 = BLS[11]
BLS12 = BLS[12]
BLS13 = BLS[13]
BLS14 = BLS[14]
BLS15 = BLS[15]
BLS16 = BLS[16]
BLS17 = BLS[17]
BLS18 = BLS[18]
BLS19 = BLS[19]
BLS20 = BLS[20]
BLS21 = BLS[21]
BLS22 = BLS[22]
BLS23 = BLS[23]

#Select State code 48 from 'Unnamed: 1' column
#we only want data for Texas hence Texas = 48

BLS10 = BLS10[BLS10['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS11 = BLS11[BLS11['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS12 = BLS12[BLS12['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS13 = BLS13[BLS13['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS14 = BLS14[BLS14['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS15 = BLS15[BLS15['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS16 = BLS16[BLS16['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS17 = BLS17[BLS17['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS18 = BLS18[BLS18['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS19 = BLS19[BLS19['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS20 = BLS20[BLS20['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS21 = BLS21[BLS21['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS22 = BLS22[BLS22['Unnamed: 1'] == '48'].reset_index(drop=True)
BLS23 = BLS23[BLS23['Unnamed: 1'] == '48'].reset_index(drop=True)

#-----------------------------------------------------------------------------------------------------------------

#Select the columns important to the dataset
#Split 'Unnamed: 3' into 'County' and 'State' columns
#Drop the old column
#Rename all of the selected columns to provide context to the data in them

BLS10 = BLS10[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS10[['County','State']] = BLS10['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS10.drop(columns = ['Unnamed: 3'], inplace = True)
BLS10 = BLS10.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS11 = BLS11[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS11[['County','State']] = BLS11['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS11.drop(columns = ['Unnamed: 3'], inplace = True)
BLS11 = BLS11.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS12 = BLS12[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS12[['County','State']] = BLS12['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS12.drop(columns = ['Unnamed: 3'], inplace = True)
BLS12 = BLS12.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS13 = BLS13[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS13[['County','State']] = BLS13['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS13.drop(columns = ['Unnamed: 3'], inplace = True)
BLS13 = BLS13.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS14 = BLS14[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS14[['County','State']] = BLS14['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS14.drop(columns = ['Unnamed: 3'], inplace = True)
BLS14 = BLS14.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS15 = BLS15[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS15[['County','State']] = BLS15['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS15.drop(columns = ['Unnamed: 3'], inplace = True)
BLS15 = BLS15.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS16 = BLS16[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS16[['County','State']] = BLS16['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS16.drop(columns = ['Unnamed: 3'], inplace = True)
BLS16 = BLS16.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS17 = BLS17[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS17[['County','State']] = BLS17['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS17.drop(columns = ['Unnamed: 3'], inplace = True)
BLS17 = BLS17.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS18 = BLS18[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS18[['County','State']] = BLS18['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS18.drop(columns = ['Unnamed: 3'], inplace = True)
BLS18= BLS18.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS19 = BLS19[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS19[['County','State']] = BLS19['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS19.drop(columns = ['Unnamed: 3'], inplace = True)
BLS19 = BLS19.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS20 = BLS20[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS20[['County','State']] = BLS20['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS20.drop(columns = ['Unnamed: 3'], inplace = True)
BLS20 = BLS20.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS21 = BLS21[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS21[['County','State']] = BLS21['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS21.drop(columns = ['Unnamed: 3'], inplace = True)
BLS21 = BLS21.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS22 = BLS22[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS22[['County','State']] = BLS22['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS22.drop(columns = ['Unnamed: 3'], inplace = True)
BLS22 = BLS22.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

BLS23 = BLS23[['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4', 'Unnamed: 9']]
BLS23[['County','State']] = BLS23['Unnamed: 3'].str.split(', ', n = 1, expand = True)
BLS23.drop(columns = ['Unnamed: 3'], inplace = True)
BLS23 = BLS23.rename(columns = {'Unnamed: 2': 'County FIPS', 'Unnamed: 4': 'Year', 'Unnamed: 9': 'Unnemployment'})

#------------------------------------------------------------------------------------------------------------------

#Concatinate all years of data into a single dataframe
#Drop the state column (redundant)
BLS = [BLS10, BLS11, BLS12, BLS13, BLS14, BLS15, BLS16, BLS17, BLS18, BLS19, BLS20, BLS21, BLS22, BLS23]
BLS = pd.concat(BLS, ignore_index=True)
BLS = BLS.drop('State', axis = 1)

#Convert 'County FIPS' and 'Year' into integers and 'Unemployment' into float values

BLS['County FIPS'] = BLS['County FIPS'].astype(int)
BLS['Year'] = BLS['Year'].astype(int)
BLS['Unnemployment'] = BLS['Unnemployment'].astype(float)

#######################################################################################################################
#######################################################################################################################

#Load in data for Crime in Texas for years 2010 - 2023

CIT = {}
for year in range (2010,2024):
    files = file_path + f'\\Crime In Texas\\NIBRS-CIT-{year}.xlsx'
    CIT[year] = pd.read_excel(files)

#Assign data to dataframes for each year

CIT10 = CIT[2010]
CIT11 = CIT[2011]
CIT12 = CIT[2012]
CIT13 = CIT[2013]
CIT14 = CIT[2014]
CIT15 = CIT[2015]
CIT16 = CIT[2016]
CIT17 = CIT[2017]
CIT18 = CIT[2018]
CIT19 = CIT[2019]
CIT20 = CIT[2020]
CIT21 = CIT[2021]
CIT22 = CIT[2022]
CIT23 = CIT[2023]

#Select important columns
#rename columns to provide context to the data
#reset the index
#drop all rows in 'County' that contain 'ALL' (this is extra data that we do not need)
#Group the rows by 'County' to combine all counties and sum the 'Violent Offences' Column
#reset the indec
#add a column for year

CIT10 = CIT10[['Unnamed: 2', '2010 TOTAL']]
CIT10 = CIT10.rename(columns = {'Unnamed: 2':'County', '2010 TOTAL': 'Violent Offences'})
CIT10 = CIT10.drop(index = 0)
CIT10 = CIT10[CIT10['County'] != 'ALL']
CIT10 = CIT10.groupby('County')['Violent Offences'].sum()
CIT10 = CIT10.reset_index()
CIT10['Year'] = 2010

CIT11 = CIT11[['Unnamed: 2', '2011 TOTAL']]
CIT11 = CIT11.rename(columns = {'Unnamed: 2':'County', '2011 TOTAL': 'Violent Offences'})
CIT11 = CIT11.drop(index = 0)
CIT11 = CIT11[CIT11['County'] != 'ALL']
CIT11 = CIT11.groupby('County')['Violent Offences'].sum()
CIT11 = CIT11.reset_index()
CIT11['Year'] = 2011

CIT12 = CIT12[['Unnamed: 2', '2012 TOTAL']]
CIT12 = CIT12.rename(columns = {'Unnamed: 2':'County', '2012 TOTAL': 'Violent Offences'})
CIT12 = CIT12.drop(index = 0)
CIT12 = CIT12[CIT12['County'] != 'ALL']
CIT12 = CIT12.groupby('County')['Violent Offences'].sum()
CIT12 = CIT12.reset_index()
CIT12['Year'] = 2012

CIT13 = CIT13[['Unnamed: 2', '2013 TOTAL']]
CIT13 = CIT13.rename(columns = {'Unnamed: 2':'County', '2013 TOTAL': 'Violent Offences'})
CIT13 = CIT13.drop(index = 0)
CIT13 = CIT13[CIT13['County'] != 'ALL']
CIT13 = CIT13.groupby('County')['Violent Offences'].sum()
CIT13 = CIT13.reset_index()
CIT13['Year'] = 2013

CIT14 = CIT14[['Unnamed: 2', '2014 TOTAL']]
CIT14 = CIT14.rename(columns = {'Unnamed: 2':'County', '2014 TOTAL': 'Violent Offences'})
CIT14 = CIT14.drop(index = 0)
CIT14 = CIT14[CIT14['County'] != 'ALL']
CIT14 = CIT14.groupby('County')['Violent Offences'].sum()
CIT14 = CIT14.reset_index()
CIT14['Year'] = 2014

CIT15 = CIT15[['Unnamed: 2', '2015 TOTAL']]
CIT15 = CIT15.rename(columns = {'Unnamed: 2':'County', '2015 TOTAL': 'Violent Offences'})
CIT15 = CIT15.drop(index = 0)
CIT15 = CIT15[CIT15['County'] != 'ALL']
CIT15 = CIT15.groupby('County')['Violent Offences'].sum()
CIT15 = CIT15.reset_index()
CIT15['Year'] = 2015

CIT16 = CIT16[['Unnamed: 2', '2016 TOTAL']]
CIT16 = CIT16.rename(columns = {'Unnamed: 2':'County', '2016 TOTAL': 'Violent Offences'})
CIT16 = CIT16.drop(index = 0)
CIT16 = CIT16[CIT16['County'] != 'ALL']
CIT16 = CIT16.groupby('County')['Violent Offences'].sum()
CIT16 = CIT16.reset_index()
CIT16['Year'] = 2016

CIT17 = CIT17[['Unnamed: 2', '2017 TOTAL']]
CIT17 = CIT17.rename(columns = {'Unnamed: 2':'County', '2017 TOTAL': 'Violent Offences'})
CIT17 = CIT17.drop(index = 0)
CIT17 = CIT17[CIT17['County'] != 'ALL']
CIT17 = CIT17.groupby('County')['Violent Offences'].sum()
CIT17 = CIT17.reset_index()
CIT17['Year'] = 2017

CIT18 = CIT18[['Unnamed: 2', '2018 TOTAL']]
CIT18 = CIT18.rename(columns = {'Unnamed: 2':'County', '2018 TOTAL': 'Violent Offences'})
CIT18 = CIT18.drop(index = 0)
CIT18 = CIT18[CIT18['County'] != 'ALL']
CIT18 = CIT18.groupby('County')['Violent Offences'].sum()
CIT18 = CIT18.reset_index()
CIT18['Year'] = 2018

CIT19 = CIT19[['Unnamed: 2', '2019 TOTAL']]
CIT19 = CIT19.rename(columns = {'Unnamed: 2':'County', '2019 TOTAL': 'Violent Offences'})
CIT19 = CIT19.drop(index = 0)
CIT19 = CIT19[CIT19['County'] != 'ALL']
CIT19 = CIT19.groupby('County')['Violent Offences'].sum()
CIT19 = CIT19.reset_index()
CIT19['Year'] = 2019

CIT20 = CIT20[['Unnamed: 2', '2020 TOTAL']]
CIT20 = CIT20.rename(columns = {'Unnamed: 2':'County', '2020 TOTAL': 'Violent Offences'})
CIT20 = CIT20.drop(index = 0)
CIT20 = CIT20[CIT20['County'] != 'ALL']
CIT20 = CIT20.groupby('County')['Violent Offences'].sum()
CIT20 = CIT20.reset_index()
CIT20['Year'] = 2020

CIT21 = CIT21[['Unnamed: 2', '2021 TOTAL']]
CIT21 = CIT21.rename(columns = {'Unnamed: 2':'County', '2021 TOTAL': 'Violent Offences'})
CIT21 = CIT21.drop(index = 0)
CIT21 = CIT21[CIT21['County'] != 'ALL']
CIT21 = CIT21.groupby('County')['Violent Offences'].sum()
CIT21 = CIT21.reset_index()
CIT21['Year'] = 2021

CIT22 = CIT22[['Unnamed: 2', '2022 TOTAL']]
CIT22 = CIT22.rename(columns = {'Unnamed: 2':'County', '2022 TOTAL': 'Violent Offences'})
CIT22 = CIT22.drop(index = 0)
CIT22 = CIT22[CIT22['County'] != 'ALL']
CIT22 = CIT22.groupby('County')['Violent Offences'].sum()
CIT22 = CIT22.reset_index()
CIT22['Year'] = 2022

CIT23 = CIT23[['Unnamed: 2', '2023 TOTAL']]
CIT23 = CIT23.rename(columns = {'Unnamed: 2':'County', '2023 TOTAL': 'Violent Offences'})
CIT23 = CIT23.drop(index = 0)
CIT23 = CIT23[CIT23['County'] != 'ALL']
CIT23 = CIT23.groupby('County')['Violent Offences'].sum()
CIT23 = CIT23.reset_index()
CIT23['Year'] = 2023

#------------------------------------------------------------------------------------------------------------

#Concatinate all datasets for each year

CIT = [CIT10, CIT11, CIT12, CIT13, CIT14, CIT15, CIT16, CIT17, CIT18, CIT19, CIT20, CIT21, CIT22, CIT23]
CIT = pd.concat(CIT, ignore_index=True)

#Convert 'Violent Offences' to an intiger for later analysis

CIT['Violent Offences'] = CIT['Violent Offences'].astype(int)

#################################################################################################################
#################################################################################################################

#Merge the Cenesus and BLS data on Year and County, all data lines up properly here

Census_BLS = pd.merge(Census, BLS, on = ['Year', 'County'], how = 'outer')

#Merge the above data to the CIT in dataframe, here we have some missing values, crime data will not be available for these counties

Real_Estate_Indicators = pd.merge(Census_BLS, CIT, on = ['Year', 'County'], how = 'outer')
Real_Estate_Indicators = Real_Estate_Indicators.drop(3556)

Real_Estate_Indicators.to_csv(file_path + '\\RealEstateIndicator.csv', index = True)
